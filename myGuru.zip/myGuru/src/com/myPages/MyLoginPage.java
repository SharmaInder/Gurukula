package com.myPages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Reporter;

import com.mySetUp.MyGlobalSetp;

public class MyLoginPage extends MyBasicPage {

	public MyLoginPage(WebDriver driver) {
		super(driver);

	}

	@FindBy(xpath = ".//*[@id='username']")
	private WebElement txtboxLogin;

	@FindBy(xpath = ".//*[@id='password']")
	private WebElement txtboxPassword;

	@FindBy(xpath = ".//*[@id='rememberMe']")
	private WebElement chkbxAutomaticLogin;

	@FindBy(xpath = "//button[@type='submit']")
	private WebElement btnAuthenticate;

	@FindBy(css = "strong")
	private WebElement lblLoginErrorMessage;

	@FindBy(linkText = "Did you forget your password?")
	private WebElement linkForgot;

	@FindBy(xpath = "//form/div/div/p")
	private List<WebElement> lblFrgtEmailErrorMsg;

	@FindBy(xpath = "/html/body/div[3]/div[1]/div/div/div/div[1]/strong")
	private WebElement lblResetPwdError;

	@FindBy(linkText = "Register a new account")
	private WebElement linkRegister;

	@FindBy(xpath = "//div[2]/div/div")
	private WebElement lblLoggedUserSuccess;

	// Forgot password Page Elements
	@FindBy(name = "email")
	private WebElement txtboxForgotPwdEmail;

	@FindBy(xpath = "//button[text()='Reset password']")
	private WebElement btnResetPassword;

	// Action methods

	public void enterUsername(String username) {
		txtboxLogin.clear();
		txtboxLogin.sendKeys(username);
	}

	public void enterPassword(String password) {
		txtboxPassword.clear();
		txtboxPassword.sendKeys(password);
	}

	public void clickAuthenticate() {
		btnAuthenticate.click();
	}

	public void checkAuthenticateCheckbox() {

		chkbxAutomaticLogin.click();

	}

	public boolean isCheckedAuthenticate() {
		return btnAuthenticate.isSelected();
	}

	public void forgotPasswordEmail(String forgotPwdEmail) {
		txtboxForgotPwdEmail.clear();
		txtboxForgotPwdEmail.sendKeys(forgotPwdEmail);
	}

	public String getFrgtEmailErrorMessage() {
		String msg = "";
		for (WebElement element : lblFrgtEmailErrorMsg) {
			if (element.getAttribute("class").equals("help-block ng-scope")) {

				msg = element.getText();
				// System.out.println("Displayed and text: " + msg);
			}

		}
		Reporter.log("Verification of Confirm Password Error Message " + msg
				+ "->");
		return msg;
	}

	public void clearForgotPwdEmail() {
		txtboxForgotPwdEmail.clear();
	}

	public String getRestPwdError() {

		return lblResetPwdError.getText();
	}

	public void clickResetPassword() {
		btnResetPassword.click();
	}

	public void clickFogotPwdLink()

	{
		linkForgot.click();

	}

	public void login(String username, String pwd) {

		enterUsername(username);
		enterPassword(pwd);
		clickAuthenticate();
	}

	public String getLoginErrorMessage() {
		if (waitForElementVisibility(lblLoginErrorMessage))
			return lblLoginErrorMessage.getText();
		else
			return "Element not visible";
	}

	public String getLoginSuccessMsg() {
		return lblLoggedUserSuccess.getText();
	}

	public void gotoLoginPage() {
		driver.get(MyGlobalSetp.myconfigMap.get("app.url") + "login");
	}
}
