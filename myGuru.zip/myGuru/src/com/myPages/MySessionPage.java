package com.myPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MySessionPage extends MyBasicPage {
	// Constructor
	public MySessionPage(WebDriver driver) {
		super(driver);

	}

	// Elements

	@FindBy(xpath = "//button[text()='Invalidate']")
	private WebElement btnInvalidate;

	@FindBy(css = "strong")
	private WebElement lblMessage;

	// Methods

	public void clickInvalidate() {
		btnInvalidate.click();
	}

	public String getSuccessMsg() {
		return lblMessage.getText();
	}

}
