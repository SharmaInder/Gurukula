package com.myPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MyHomePage extends MyBasicPage {

	// Constructor
	public MyHomePage(WebDriver driver) {
		super(driver);

	}

	@FindBy(linkText = "login")
	private WebElement linkLogin;

	@FindBy(linkText = "Register a new account")
	private WebElement linkRegister;

	// Click login link
	public void clickLogin() {
		linkLogin.click();
	}

	// Click Register link
	public void clickRegisterLink() {
		linkRegister.click();
	}

}
