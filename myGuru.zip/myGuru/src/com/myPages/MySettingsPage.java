package com.myPages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

public class MySettingsPage extends MyBasicPage {

	public MySettingsPage(WebDriver driver) {
		super(driver);
	}

	// elements

	@FindBy(name = "firstName")
	private WebElement txtboxFirstName;

	@FindBy(name = "lastName")
	private WebElement txtboxLastName;

	@FindBy(name = "email")
	private WebElement txtboxEmail;

	@FindBy(name = "langKey")
	private WebElement drpdwnLang;

	@FindBy(xpath = "//div[3]/strong")
	private WebElement lblSettingsErrorMsg;

	@FindBy(xpath = "//form/button[text()='Save']")
	private WebElement btnSave;

	// Email Error Text Label
	@FindBy(xpath = "//div[3]/div/p")
	private List<WebElement> lblEmailError;

	// Methods

	public String getSettingsError() {

		WebDriverWait wait = new WebDriverWait(driver, this.getTimeout());
		wait.until(ExpectedConditions
				.visibilityOf(lblSettingsErrorMsg));

		return lblSettingsErrorMsg.getText();
	}

	public void clickSave() {
		if (btnSave.isEnabled()) {
			btnSave.click();
		} else {
			System.out.println("Save button is disabled!");
		}
	}

	public void enterFirstName(String fname) {
		txtboxFirstName.sendKeys(fname);
	}

	public void clearFirstName() {
		txtboxFirstName.clear();
	}

	public void enterLastName(String lname) {
		txtboxLastName.sendKeys(lname);
	}

	public void clearLastName() {
		txtboxLastName.clear();
	}

	public void enterEmailName(String email) {
		txtboxEmail.clear();
		txtboxEmail.sendKeys(email);
	}

	public void clearEmail() {
		txtboxEmail.clear();
	}

	public String getEmailErrorMessage() {
		String msg = "";
		for (WebElement element : lblEmailError) {

			if (element.getAttribute("class").equals("help-block ng-scope")) {
				this.waitForElementVisibility(element);
				msg = element.getText();
				// System.out.println("Displayed and text: " + msg);
			}

		}
		Reporter.log("Verification of Email Error Message " + msg + "->");
		return msg;
	}
}
