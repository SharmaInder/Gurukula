package com.myPages;

public interface MyTestData {

	final String validId = "admin";
	final String validPassword = "admin";
	final String blankId = " ";
	final String blankPassword = " ";
	final String InvalidId = "User";
	final String InvalidPassword = "Mypwd";

	final int Case1 = 1;
	final int Case2 = 2;
	final int Case3 = 3;
	final int Case4 = 4;
	final int Case5 = 5;
	final int Case6 = 6;
	final int Case7 = 7;
	final int Case8 = 8;
	final int Case9 = 9;
	final int Case10 = 10;
	final int Case11 = 11;
	final int Case12 = 12;
	final int Case13 = 13;

	final String email1 = "inderEmail";
	final String email1Msg = "Your e-mail is invalid.";
	final String email2 = "123@1.com";
	final String email2Msg = "Your e-mail is required.";
	final String email3 = "1@11";
	final String email3Msg = "Your e-mail is required to be at least 5 characters.";
	final String email4 = "96584521584563qweqecewvcrertvvtybybty@com";
	final String email4Msg = "Your e-mail cannot be longer than 50 characters.";
	final String email5 = "indrajeet.sharma@gmail.com";
	final String email5Msg = "E-Mail address isn't registered!";
	final String email6 = "admin@localhost";
	final String blankData = "";

	final String branch1Name = "Administrator";
	final String branch1Code = "ADM01";
	final String branch2Name = "Passenger Management";
	final String branch2Code = "PAS01";
	final String branch3Name = "Cargo Management";
	final String branch3Code = "CGO01";
	final String branch4Name = "Crew Management";
	final String branch4Code = "CRW01";
	final String branch5Name = "Flight Management";
	final String branch5Code = "FLT01";

	final String branch1NameError = "Adm";
	final String branch3NameError = "BranchMyName";
	final String branch4NameError = "Branch123";

	final String branch5IdError = "B";
	final String branch6IdError = "BRN098048392";
	final String branch7IdError = "qwer01";

	final String branchOrStaff1Msg = "This field is required.";
	final String branch2Msg = "This field is required to be at least 5 characters.";
	final String branch3Msg = "This field cannot be longer than 20 characters.";
	final String branchorStaff4_3Msg = "This field should follow pattern ^[a-zA-Z\\s]*$.";
	final String branch5Msg = "This field is required to be at least 2 characters.";
	final String branch6Msg = "This field cannot be longer than 10 characters.";
	final String branch7Msg = "This field should follow pattern ^[A-Z0-9]*$.";

	final String staff1Name = "Mr Subbu Shankar"; // branch1Name
	final String staff2Name = "Mrs Prity Sharma";// branch2Name
	final String staff3Name = "Dr Sashi Priya";// branch4Name
	final String staff4Name = "Mrs Shephali Tandon";// branch2Name
	final String staff5Name = "Mr Ramachandra Sahil";// branch5Name
	final String staff6Name = "Mr IamEmpty";// blankData

	final String staff1ErrName = "name"; // branchOrStaff1Msg
	final String staff2ErrName = "AbcdMyOwnName";// staff2Msg
	final String staff3ErrName = "Abcd Abcd8910";// branchorStaff4_3Msg

	final String staff2Msg = "This field cannot be longer than 50 characters.";

	final String AccPWD1Type = "Test@2019!!!!!";// 1, AccPWD1Type,
												// blankData,AccPWD1Msg
	final String AccPWD2Type = "Test@2019";// 2, AccPWD2Type, blankData,
											// AccPWD2Msg
	final String AccPWD3_13Type = "12345";// 3, AccPWD3_13Type, blankData,
											// AccPWD3Msg
	final String AccPWD4Type = "12345abcde";// 4, AccPWD4Type, blankData,
											// AccPWD4Msg
	final String AccPWD5Type = "password";// 5, AccPWD5Type, blankData,
											// AccPWD5Msg
	final String AccPWD6Type = "p";// 6, AccPWD6Type, blankData, AccPWD6Msg
	final String AccPWD7_10Type = "1234567890password1234567890password1234567password";// 7,
																						// AccPWD7_10Type,
																						// blankData,
																						// AccPWD7Msg
	final String AccPWD8_12Type = "25365$";// 8, AccPWD8_12Type, blankData,
											// AccPWD8_12Msg
	final String AccPWD9Type = "598658";// 9, blankData, AccPWD9Type, AccPWD9Msg
	// 10, blankData, AccPWD7_10Type,AccPWD7_10Msg
	final String AccPWD11Type = "54";// 11,blankData, AccPWD11Type, AccPWD11Msg
	// 12, blankData, AccPWD8_12Type, AccPWD8_12Msg
	final String AccPWD13Type = "25896";// 13,AccPWD13Type, AccPWD3_13Type,
										// AccPWD13Msg

	final String AccPWD1Msg = "Very Strong";
	final String AccPWD2Msg = "Strong";
	final String AccPWD3Msg = "Very Weak";
	final String AccPWD4Msg = "Weak";
	final String AccPWD5Msg = "Your password is required.";
	final String AccPWD6Msg = "Your password is required to be at least 5 characters.";
	final String AccPWD7_10Msg = "Your password cannot be longer than 50 characters.";
	final String AccPWD8_12Msg = "Password should begin with a alphabet and should contain a number and a special character.";
	final String AccPWD9Msg = "Your confirmation password is required.";
	final String AccPWD11Msg = "Your confirmation password is required to be at least 5 characters.";
	final String AccPWD13Msg = "The password and its confirmation do not match!";

	class LoginData implements MyTestData {
	}

	class BranchData implements MyTestData {
	}

	class StaffData implements MyTestData {
	}

	class MyAccountdata implements MyTestData {
	}

}
