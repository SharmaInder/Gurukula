package com.myUseCase;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.myPages.MYMenuPage;
import com.myPages.MyHomePage;
import com.myPages.MyLoginPage;
import com.myPages.MyStaffPage;
import com.myPages.MyTestData;
import com.mySetUp.MyGlobalSetp;

public class MyStaff implements MyTestData {

	private MyGlobalSetp myGsetup;
	protected static WebDriver driver;

	MyLoginPage loginpagedata;
	MyHomePage myHomePagedata;
	MYMenuPage menupage;
	MyStaffPage staffpagedata;

	@BeforeTest
	public void startTest() throws IOException, InterruptedException {
		myGsetup = new MyGlobalSetp();
		driver = myGsetup.setup();
		loginpagedata = new MyLoginPage(driver);
		myHomePagedata = new MyHomePage(driver);
		menupage = new MYMenuPage(driver);
		staffpagedata = new MyStaffPage(driver);
		myHomePagedata.clickLogin();
		loginpagedata.login(LoginData.validId, LoginData.validPassword);

	}

	@Test(enabled = true, priority = 1)
	public void Guru5_TS03_Verify_StaffEdit() {

		// Create a new Staff
		Guru5_TS01_Create_new_staff("Mr Original", "Administrator");
		// Edit the newly created staff
		staffpagedata.clickEdit();

		staffpagedata.enterStaffName("Mr Edited Staff");
		staffpagedata.selectBranchName("Verify Edit");

		staffpagedata.clickSave();

		// Verify if Staff is Edited or not

		String staffDetail[] = staffpagedata.getNewlyCreatedStaff();
		Reporter.log("Verification of recently Edited Staff Name");
		assertTrue(staffDetail[0].contains("Mr Edited Staff"));
		Reporter.log("Verification of Newly Edited Branch Code");
		assertTrue(staffDetail[1].contains("Verify Edit"));

	}

	@Test(enabled = true, priority = 2)
	public void Guru5_TS04_Verify_StaffDelete() {
		// Create a new Staff
		Guru5_TS01_Create_new_staff("Mr To be Deleted", "Crew Management");
		// Delete the newly created staff
		staffpagedata.clickDelete();
		staffpagedata.clickConfirmDelete();

		// refresh DOM
		driver.navigate().refresh();

		// Verify if Staff is deleted or not

		String staffDetails[] = staffpagedata.getNewlyCreatedStaff();
		Reporter.log("Verification of recently deleted Staff Name");
		assertFalse(staffDetails[0].contains("Mr To be Deleted"));
		Reporter.log("Verification of recently deleted Branch Code");
		assertFalse(staffDetails[1].contains("Crew Management"));

	}

	@Test(enabled = true, priority = 3)
	public void Guru5_TS05_Verify_StaffView() {
		// Create a new Staff
		Guru5_TS01_Create_new_staff("Verify Branch View", "Administrator");

		// Click View button of the newly created Staff
		staffpagedata.clickView();
		Reporter.log("Verification of recently created Staff Name");
		assertEquals(staffpagedata.getLblViewStaffName(), "Verify Branch View");

		Reporter.log("Verification of Newly created Branch Name");
		assertEquals(staffpagedata.getLblViewBranchName(), "Administrator");

	}

	@Test(priority = 4, dataProvider = "dataForStaffTest", enabled = true)
	public void Guru5_TS01_Create_new_staff(String staffName, String branchName) {

		menupage.clickStaff();

		staffpagedata.clickCreateNewStaff();

		staffpagedata.enterStaffName(staffName);

		staffpagedata.selectBranchName(branchName);

		staffpagedata.clickSave();
		driver.navigate().refresh();

		// Verify Newly created branch
		String staffDetails[] = staffpagedata.getNewlyCreatedStaff();
		Reporter.log("Verification of Newly created Staff Name");
		assertEquals(staffDetails[0], staffName);
		Reporter.log("Verification of Newly created Branch Names");
		assertEquals(staffDetails[1], branchName);

	}

	@Test(priority = 5, dataProvider = "dataForStaffErrorHandlingTest", enabled = true)
	public void Guru5_TS02_Verify_StaffCreationError_Message_Handling(
			String id, String staffName, String msg) {
		driver.navigate().refresh();
		menupage.clickStaff();

		staffpagedata.clickCreateNewStaff();

		switch (id) {
		case "1":
			assertEquals(staffpagedata.getStaffNameErrorMessage(), msg);
			break;
		case "2":
			staffpagedata.enterStaffName(staffName);
			assertEquals(staffpagedata.getStaffNameErrorMessage(), msg);
			break;

		case "3":
			staffpagedata.enterStaffName(staffName);
			assertEquals(staffpagedata.getStaffNameErrorMessage(), msg);
			break;

		}

		staffpagedata.clickCancel();

	}

	@AfterTest
	public void finishTest() {

		myGsetup.cleanup();
	}

	// TEST DATA FOR STAFF TEST
	@DataProvider(name = "dataForStaffTest")
	public Object[][] getStaffData() {
		return new Object[][] {
				{ StaffData.staff1Name, StaffData.branch1Name },
				{ StaffData.staff2Name, StaffData.branch2Name },
				{ StaffData.staff3Name, StaffData.branch4Name },
				{ StaffData.staff4Name, StaffData.branch2Name },
				{ StaffData.staff5Name, StaffData.branch5Name },
				{ StaffData.staff6Name, StaffData.blankData },

		};
	}

	@DataProvider(name = "dataForStaffErrorHandlingTest")
	public Object[][] getStaffErrorMessageData() {
		return new Object[][] {
				{ String.valueOf(StaffData.Case1), StaffData.staff1ErrName,
						StaffData.branchOrStaff1Msg, },
				{
						String.valueOf(StaffData.Case2),
						StaffData.staff2ErrName + " " + StaffData.staff2ErrName
								+ " " + StaffData.staff2ErrName,
						StaffData.staff2Msg, },
				{ String.valueOf(StaffData.Case3), StaffData.staff3ErrName,
						StaffData.branchorStaff4_3Msg, },

		};
	}

}
