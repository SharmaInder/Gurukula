package com.myUseCase;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.myPages.MYMenuPage;
import com.myPages.MyHomePage;
import com.myPages.MyLoginPage;
import com.myPages.MyTestData;
import com.mySetUp.MyGlobalSetp;

public class MyLogin implements MyTestData {

	private MyGlobalSetp myGsetup;
	private WebDriver driver;

	MyLoginPage loginpagedata;
	MyHomePage myhomegagedata;
	MYMenuPage menupagedata;

	@BeforeTest
	public void startTest() {
		myGsetup = new MyGlobalSetp();
		driver = myGsetup.setup();
		loginpagedata = new MyLoginPage(driver);
		myhomegagedata = new MyHomePage(driver);
		menupagedata = new MYMenuPage(driver);
	}

	@Test()
	public void Guru1_TS01_Login_VerifyApplicationIsUpandRunning() {
		Reporter.log("In Guru1_TS01_Login_VerifyApplicationIsUpandRunning:- To verify Application is running");
		Assert.assertTrue(driver.getTitle().contains("gurukula"));

	}

	@Test(dataProvider = "myTestdataForValidLoginTest", enabled = true)
	public void Guru1_TS02_VerifyValidLogin(String username, String password) {
		Reporter.log("Inside Guru1_TS02_VerifyValidLogin");
		myhomegagedata.clickLogin();
		Reporter.log("Please Click Login Button");
		loginpagedata.enterUsername(username);
		Reporter.log("Please Enter the Username <" + username + ">");
		loginpagedata.enterPassword(password);
		Reporter.log("Please Enter the Password <" + password + ">");
		loginpagedata.clickAuthenticate();
		Reporter.log("Please Click on Authenticate Button");

		assertEquals(loginpagedata.getLoginSuccessMsg(),
				"You are logged in as user \"" + username + "\".");
		Reporter.log("Login sucessful\n");
		menupagedata.clickLogout();
		Reporter.log("Logout");
		menupagedata.clickHome();

	}

	@Test(dataProvider = "myTestdataForInvalidLoginTest", enabled = true)
	public void Guru1_TS03_VerifyInvalidLogin(String username, String password) {
		Reporter.log("Inside Guru1_TS03_VerifyInvalidLogin");
		myhomegagedata.clickLogin();
		loginpagedata.enterUsername(username);
		loginpagedata.enterPassword(password);
		loginpagedata.clickAuthenticate();

		assertEquals(loginpagedata.getLoginErrorMessage(),
				"Authentication failed!");

	}

	@Test(dataProvider = "mydataForRestPwdTest", enabled = true)
	public void Guru1_TS04_VerifyResetPWD(String id, String forgotPwdEmail,
			String msg) {

		Reporter.log("Inside Guru1_TS04_VerifyResetPWD ");

		myhomegagedata.clickLogin();
		loginpagedata.clickFogotPwdLink();

		switch (id) {
		case "1":
			loginpagedata.forgotPasswordEmail(forgotPwdEmail);
			assertEquals(loginpagedata.getFrgtEmailErrorMessage(), msg);
			break;

		case "2":
			loginpagedata.forgotPasswordEmail(forgotPwdEmail);
			loginpagedata.clearForgotPwdEmail();
			assertEquals(loginpagedata.getFrgtEmailErrorMessage(), msg);
			break;

		case "3":
			loginpagedata.forgotPasswordEmail(forgotPwdEmail);
			assertEquals(loginpagedata.getFrgtEmailErrorMessage(), msg);
			break;

		case "4":
			loginpagedata.forgotPasswordEmail(forgotPwdEmail);
			assertEquals(loginpagedata.getFrgtEmailErrorMessage(), msg);
			break;

		case "5":
			loginpagedata.forgotPasswordEmail(forgotPwdEmail);
			loginpagedata.clickResetPassword();
			assertEquals(loginpagedata.getRestPwdError(), msg);
			break;

		case "6":
			loginpagedata.forgotPasswordEmail(forgotPwdEmail);
			loginpagedata.clickResetPassword();
			assertEquals(loginpagedata.getRestPwdError(), msg);
			break;

		}

	}

	@AfterMethod
	public void goToMyHomePage() {

		menupagedata.clickHome();

	}

	@AfterTest
	public void finishTest() {

		myGsetup.cleanup();
	}

	// / TEST DATA FOR LOGIN TEST

	@DataProvider(name = "myTestdataForInvalidLoginTest")
	public Object[][] getLoginInvalidData() {
		return new Object[][] { { LoginData.blankId, LoginData.blankPassword },
				{ LoginData.validId, LoginData.InvalidPassword },
				{ LoginData.InvalidId, LoginData.validPassword },
				{ LoginData.InvalidId, LoginData.InvalidPassword } };
	}

	@DataProvider(name = "myTestdataForValidLoginTest")
	public Object[][] getLoginValidData() {
		return new Object[][] { { LoginData.validId, LoginData.validPassword } };
	}

	@DataProvider(name = "mydataForRestPwdTest")
	public Object[][] getResetPasswordData1() {
		return new Object[][] {
				{ String.valueOf(LoginData.Case1), LoginData.email1,
						LoginData.email1Msg },
				{ String.valueOf(LoginData.Case2), LoginData.email2,
						LoginData.email2Msg },
				{ String.valueOf(LoginData.Case3), LoginData.email3,
						LoginData.email3Msg },
				{ String.valueOf(LoginData.Case4), LoginData.email4,
						LoginData.email4Msg },
				{ String.valueOf(LoginData.Case5), LoginData.email5,
						LoginData.email5Msg },
				{ String.valueOf(LoginData.Case6), LoginData.email6,
						LoginData.blankData }, };
	}

}
