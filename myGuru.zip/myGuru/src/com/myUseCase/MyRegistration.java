package com.myUseCase;

import static org.testng.Assert.assertEquals;
import com.mySetUp.*;
import com.myPages.*;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


public class MyRegistration {

	private MyGlobalSetp myGsetup;
	private WebDriver driver;
	MyLoginPage loginpage;
	MyHomePage myhomegagedata;
	MYMenuPage menupagedata;
	MyRegistrationPage registerpagedata;

	@BeforeTest
	public void startTest() {
		myGsetup = new MyGlobalSetp();
		driver = myGsetup.setup();
		myhomegagedata = new MyHomePage(driver);
		menupagedata = new MYMenuPage(driver);
		registerpagedata = new MyRegistrationPage(driver);
	}

	@Test(dataProvider = "MydataForRegisterationTest", enabled = true)
	public void Guru2_TS02_Verify_NewUser_Registration(String loginName,
			String email, String password, String confPassword) {
		Reporter.log("Click on Register a new account link: ");
		myhomegagedata.clickRegisterLink();

		registerpagedata.fillRegistrationForm(loginName, email, password,
				confPassword);

		Reporter.log("Click Register Button: ");
		registerpagedata.clickRegister();

		Reporter.log("Verify Success Message");
		assertEquals(registerpagedata.getRegistrationError(),
				"Registration Success!");

	}

	@Test(dataProvider = "MydataForPwdStrengthTest", enabled = true)
	public void Guru2_TS02_VerifyPasswordStrength(String loginName, String email,
			String password, String confPassword, String msg) {
		Reporter.log("Click Register a new account link: ");
		myhomegagedata.clickRegisterLink();

		registerpagedata.fillRegistrationForm(loginName, email, password,
				confPassword);
		assertEquals(registerpagedata.getPasswordStrength(), msg);
	}

	@Test(dataProvider = "MydataForFieldErrorsTest", enabled = true)
	public void Guru2_TS03_Registeration_ErrorMessageVerification(String id,
			String loginName, String email, String pwd, String cnfPwd,
			String msg) throws InterruptedException {
		Reporter.log("Click Register a new account link: ");
		myhomegagedata.clickRegisterLink();

		switch (id) {
		case "1":
			registerpagedata.enterLoginName(loginName);
			registerpagedata.clearLoginNameField();
			assertEquals(registerpagedata.getLoginErrorMessage(), msg);

			break;
		case "2":
			registerpagedata.enterLoginName(loginName);
			assertEquals(registerpagedata.getLoginErrorMessage(), msg);

			break;
		case "3":
			registerpagedata.enterLoginName(loginName);
			assertEquals(registerpagedata.getLoginErrorMessage(), msg);
			break;
		case "4":
			registerpagedata.enterEmail(email);
			assertEquals(registerpagedata.getEmailErrorMessage(), msg);
			break;
		case "5":
			registerpagedata.enterEmail(email);
			registerpagedata.clearEmailField();
			assertEquals(registerpagedata.getEmailErrorMessage(), msg);
			break;
		case "6":
			registerpagedata.enterEmail(email);
			assertEquals(registerpagedata.getEmailErrorMessage(), msg);
			break;
		case "7":
			registerpagedata.enterEmail(email);
			assertEquals(registerpagedata.getEmailErrorMessage(), msg);
			break;
		case "8":
			registerpagedata.enterPassword(pwd);
			registerpagedata.clearPasswordField();
			assertEquals(registerpagedata.getPasswordErrorMessage(), msg);
			break;
		case "9":
			registerpagedata.enterPassword(pwd);
			assertEquals(registerpagedata.getPasswordErrorMessage(), msg);
			break;
		case "10":
			registerpagedata.enterPassword(pwd);
			assertEquals(registerpagedata.getPasswordErrorMessage(), msg);
			break;
		case "11":
			registerpagedata.enterPassword(pwd);
			assertEquals(registerpagedata.getPasswordErrorMessage(), msg);
			break;
		case "12":
			registerpagedata.enterConfirmPassword(cnfPwd);
			registerpagedata.clearCnfPasswordField();
			assertEquals(registerpagedata.getConfirmPasswordErrorMessage(), msg);
			break;
		case "13":
			registerpagedata.enterConfirmPassword(cnfPwd);
			assertEquals(registerpagedata.getConfirmPasswordErrorMessage(), msg);
			break;

		case "14":
			registerpagedata.enterConfirmPassword(cnfPwd);
			assertEquals(registerpagedata.getConfirmPasswordErrorMessage(), msg);
			break;
		case "15":
			registerpagedata.enterConfirmPassword(cnfPwd);
			assertEquals(registerpagedata.getConfirmPasswordErrorMessage(), msg);
			break;
		case "16":
			registerpagedata.fillRegistrationForm(loginName, email, pwd, cnfPwd);
			registerpagedata.clickRegister();
			assertEquals(registerpagedata.getPasswordMismatchError(), msg);
			break;

		}

	}

	@Test(enabled = true)
	public void Guru2_TS04_VerifyRegistrationEnable() {

		myhomegagedata.clickRegisterLink();

		registerpagedata.enterLoginName("user");
		assertFalse(registerpagedata.isRegisterBtnEnable());

		registerpagedata.enterEmail("abc@def.com");
		assertFalse(registerpagedata.isRegisterBtnEnable());

		registerpagedata.enterPassword("password");
		assertFalse(registerpagedata.isRegisterBtnEnable());

		registerpagedata.enterConfirmPassword("password");

		assertTrue(registerpagedata.isRegisterBtnEnable());

	}

	@AfterMethod
	public void goToMyHomePage() {

		menupagedata.clickHome();

	}

	@AfterTest
	public void finishTest() {

		myGsetup.cleanup();
	}

	// TEST DATA FOR REGISTRATION TEST
	@DataProvider(name = "MydataForRegisterationTest")
	public Object[][] getRegistrationData() {
		return new Object[][] { { "indrajeet", "indrajeet@ibsplc.com",
				"Test@2019!!!!!", "Test@2019!!!!!" } };
	}

	@DataProvider(name = "MydataForPwdStrengthTest")
	public Object[][] getPasswordStrengthData() {
		return new Object[][] {

				{ "indrajeet", "indrajeet@ibsplc.com", "Test@2019!!!!!", "",
						"Very Strong" },
				{ "indrajeet", "indrajeet@ibsplc.com", "Test@2019", "",
						"Strong" },
				{ "indrajeet", "indrajeet@ibsplc.com", "12345", "",
						"Very Weak" },
				{ "indrajeet", "indrajeet@ibsplc.com", "12345abcde", "",
						"Weak" }

		};
	}

	@DataProvider(name = "MydataForFieldErrorsTest")
	public Object[][] getFieldsData() {
		return new Object[][] {
				{ "1", "A", "email", "password", "confirmpass",
						"Your login is required." },
				{ "2", "A123", "email", "password", "confirmpass",
						"Your login can only contain lower-case letters and digits." },
				{ "3", "a123456789012345678901234567890123456789012345678901",
						"", "", "",
						"Your login cannot be longer than 50 characters." },
				{ "4", "user", "email", "", "", "Your e-mail is invalid." },
				{ "5", "user", "a@a.com", "", "", "Your e-mail is required." },
				{ "6", "user", "a@a", "", "",
						"Your e-mail is required to be at least 5 characters." },
				{ "7", "user",
						"email1234567890123456789012345678901234567812@com",
						"", "",
						"Your e-mail cannot be longer than 50 characters." },
				{ "8", "user", "a@abc.com", "password", "",
						"Your password is required." },
				{ "9", "user", "a@abc.com", "p", "",
						"Your password is required to be at least 5 characters." },
				{ "10", "user", "a@abc.com",
						"password1234567890password1234567890password1234567",
						"",
						"Your password cannot be longer than 50 characters." },
				{
						"11",
						"user",
						"a@abc.com",
						"12345$",
						"",
						"Password should begin with a alphabet and should contain a number and a special character." },
				{ "12", "user", "a@a", "", "112345",
						"Your confirmation password is required." },
				{ "13", "user", "a@a", "",
						"password1234567890password1234567890password1234567",
						"Your confirmation password cannot be longer than 50 characters." },
				{ "14", "user", "a@a", "", "12",
						"Your confirmation password is required to be at least 5 characters." },
				{
						"15",
						"user",
						"a@a",
						"",
						"12345$",
						"Password should begin with a alphabet and should contain a number and a special character." },
				{ "16", "user", "a@a.com", "12345", "45678",
						"The password and its confirmation do not match!" }, };
	}
}
