package com.myUseCase;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.myPages.MYMenuPage;
import com.myPages.MyBranchPage;
import com.myPages.MyHomePage;
import com.myPages.MyLoginPage;
import com.myPages.MyTestData;
import com.mySetUp.MyGlobalSetp;

public class MyBranch implements MyTestData {

	private MyGlobalSetp myGsetup;
	private WebDriver driver;

	MyLoginPage loginpage;
	MyHomePage MyHomePage;
	MYMenuPage menupage;
	MyBranchPage branchpage;

	@BeforeTest
	public void startTest() {
		myGsetup = new MyGlobalSetp();
		driver = myGsetup.setup();
		loginpage = new MyLoginPage(driver);
		MyHomePage = new MyHomePage(driver);
		menupage = new MYMenuPage(driver);
		branchpage = new MyBranchPage(driver);
		MyHomePage.clickLogin();
		loginpage.login(LoginData.validId, LoginData.validId);

	}

	@Test(priority = 1, enabled = true)
	public void Guru4TS03_Verify_BranchEdit() throws InterruptedException {
		// Create a new branch
		Guru4TS01_Create_newBranch("Original", "ORIG01");
		// Edit the newly created Branch
		branchpage.clickEdit();

		branchpage.enterBranchName("Verify Edit");
		branchpage.enterBranchCode("EDIT01");
		branchpage.clickSave();

		// Verify if Branch is Edited or not

		String branchDetails[] = branchpage.getNewlyCreatedBranch();
		Reporter.log("Verification of recently Edited Branch Name");
		assertTrue(branchDetails[0].contains("Verify Edit"));
		Reporter.log("Verification of Newly Edited Branch Code");
		assertTrue(branchDetails[1].contains("EDIT01"));

	}

	@Test(priority = 2, enabled = true)
	public void Guru4TS04_Verify_BranchDelete() throws InterruptedException {

		// Create a new branch
		Guru4TS01_Create_newBranch("Verify Delete", "DEL01");

		// Delete the newly created Branch
		branchpage.clickDelete();
		branchpage.clickConfirmDelete();

		// refresh DOM
		driver.navigate().refresh();

		// Verify if Branch is deleted or not

		String branchDetails[] = branchpage.getNewlyCreatedBranch();
		Reporter.log("Verification of recently deleted Branch Name");
		assertFalse(branchDetails[0].contains("Verify Delete"));
		Reporter.log("Verification of Newly deleted Branch Code");
		assertFalse(branchDetails[1].contains("DEL01"));

	}

	@Test(priority = 3)
	public void Guru4TS05_Verify_BranchView() throws InterruptedException {
		// Create a new branch
		Guru4TS01_Create_newBranch("Verify Branch View", "VIEW01");

		// Click View button of the newly created Branch
		branchpage.clickView();
		Reporter.log("Verification of recently created Branch Name");
		assertEquals(branchpage.getLblViewBranchName(), "Verify Branch View");

		Reporter.log("Verification of Newly created Branch Code");
		assertEquals(branchpage.getLblViewBranchCode(), "VIEW01");

	}

	@Test(priority = 4, dataProvider = "dataForBranchTest", enabled = true)
	public void Guru4TS01_Create_newBranch(String branchName, String branchCode)
			throws InterruptedException {

		menupage.clickBranch();

		branchpage.clickCreatNewBranch();

		branchpage.enterBranchName(branchName);
		branchpage.enterBranchCode(branchCode);

		branchpage.clickSave();

		// Verify Newly created branch
		String branchDetails[] = branchpage.getNewlyCreatedBranch();
		Reporter.log("Verification of Newly created Branch Name");
		assertEquals(branchDetails[0], branchName);
		Reporter.log("Verification of Newly created Branch Code");
		assertEquals(branchDetails[1], branchCode);
	}

	@Test(priority = 5, dataProvider = "dataForBranchErrorHandlingTest", enabled = true)
	public void Guru4TS02_Verify_BranchCreationError_Message_Handling(
			String id, String branchName, String branchCode, String msg)
			throws InterruptedException {

		driver.navigate().refresh();
		menupage.clickBranch();

		branchpage.clickCreatNewBranch();

		switch (id) {
		case "1":
			assertEquals(branchpage.getBranchNameErrorMessage(), msg);
			break;
		case "2":
			branchpage.enterBranchName(branchName);
			branchpage.enterBranchCode(branchCode);
			assertEquals(branchpage.getBranchNameErrorMessage(), msg);
			break;

		case "3":
			branchpage.enterBranchName(branchName);
			branchpage.enterBranchCode(branchCode);
			assertEquals(branchpage.getBranchNameErrorMessage(), msg);
			break;
		case "4":
			branchpage.enterBranchName(branchName);
			branchpage.enterBranchCode(branchCode);
			assertEquals(branchpage.getBranchNameErrorMessage(), msg);
			break;
		case "5":
			branchpage.enterBranchName(branchName);
			branchpage.enterBranchCode(branchCode);
			assertEquals(branchpage.getBranchCodeErrorMessage(), msg);
			break;
		case "6":
			branchpage.enterBranchName(branchName);
			branchpage.enterBranchCode(branchCode);
			assertEquals(branchpage.getBranchCodeErrorMessage(), msg);
			break;
		case "7":
			branchpage.enterBranchName(branchName);
			branchpage.enterBranchCode(branchCode);
			assertEquals(branchpage.getBranchCodeErrorMessage(), msg);
			break;

		case "8":
			branchpage.enterBranchName(branchName);
			branchpage.enterBranchCode(branchCode);
			assertEquals(branchpage.getBranchCodeErrorMessage(), msg);
			break;

		}
		branchpage.clickCancel();

	}

	@AfterTest
	public void finishTest() {

		myGsetup.cleanup();

	}

	// TEST DATA FOR STAFF TEST
	@DataProvider(name = "dataForBranchTest")
	public Object[][] getBranchData() {
		return new Object[][] {
				{ BranchData.branch1Name, BranchData.branch1Code },
				{ BranchData.branch2Name, BranchData.branch2Code },
				{ BranchData.branch3Name, BranchData.branch3Code },
				{ BranchData.branch4Name, BranchData.branch4Code },
				{ BranchData.branch5Name, BranchData.branch5Code }, };
	}

	@DataProvider(name = "dataForBranchErrorHandlingTest")
	public Object[][] getBranchErrorMessageData() {
		return new Object[][] {
				{ String.valueOf(BranchData.Case1), BranchData.blankData,
						BranchData.blankData, BranchData.branchOrStaff1Msg },
				{ String.valueOf(BranchData.Case2),
						BranchData.branch1NameError, BranchData.branch1Code,
						BranchData.branch2Msg },
				{ String.valueOf(BranchData.Case3),
						BranchData.branch3NameError + " " + branch3NameError,
						BranchData.branch1Code, BranchData.branch3Msg },
				{ String.valueOf(BranchData.Case4),
						BranchData.branch4NameError, BranchData.branch1Code,
						BranchData.branchorStaff4_3Msg },
				{ String.valueOf(BranchData.Case5),
						BranchData.branch3NameError, BranchData.branch5IdError,
						BranchData.branch5Msg },
				{ String.valueOf(BranchData.Case6),
						BranchData.branch3NameError, BranchData.branch6IdError,
						BranchData.branch6Msg },
				{ String.valueOf(BranchData.Case7),
						BranchData.branch3NameError, BranchData.branch7IdError,
						BranchData.branch7Msg },

		};
	}

}
