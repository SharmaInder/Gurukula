package com.mySetUp;

import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

public class MyGlobalSetp {
	public WebDriver driver;
	public static Map<String, String> myconfigMap;

	public MyGlobalSetp() {
		this.getProperty();
	}

	public void getProperty() {
		myconfigMap = new HashMap<String, String>();
		Properties prop = new Properties();

		try {
			FileInputStream inputStream = new FileInputStream(
					"config.properties");
			prop.load(inputStream);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error in loading config.properties...! "
					+ e.getMessage());

		}
		for (final Entry<Object, Object> entry : prop.entrySet()) {
			myconfigMap.put((String) entry.getKey(), (String) entry.getValue());

		}

	}

	// Setup function
	public WebDriver setup() {

		if (MyGlobalSetp.myconfigMap.get("test.browser").equalsIgnoreCase(
				"chrome")) {
			System.setProperty("webdriver.chrome.driver",
					"driver/chromedriver.exe");
			driver = new ChromeDriver();

		} else if (MyGlobalSetp.myconfigMap.get("test.browser")
				.equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.gecko.driver",
					"driver/geckodriver.exe");
			FirefoxOptions opt = new FirefoxOptions();
			opt.setCapability("marionette", false);

			driver = new FirefoxDriver(opt);
		} else {
			System.out.println("Check browser settings in config file!");
		}

		driver.manage()
				.timeouts()
				.implicitlyWait(
						Integer.parseInt(MyGlobalSetp.myconfigMap
								.get("guru.implicitwait")), TimeUnit.SECONDS);

		driver.manage().window().maximize();
		driver.get(MyGlobalSetp.myconfigMap.get("guru.url"));

		return driver;

	}

	// Cleanup function
	public void cleanup() {
		driver.quit();
	}
}
